﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Threading.Tasks;

namespace FlightControlWeb.Models
{
    public class Flight
    {
        public string FlightID { get; set; }
        public string CompanyName { get; set; }
        public double Longitude { get; set; }
        public double Latitude { get; set; }
        public int NumberOfPassenger { get; set; }
        public string DateAndTime { get; set; }
        public bool IsExternal { get; set; }
        // private FlightModel flightModel = new FlightModel();
        private static List<FlightPlan> FlightPlan = new List<FlightPlan>()
        {
            new FlightPlan {CompanyName = "el-al", NumberOfPassenger=200,
                Initial_location =new Dictionary<string, string>()
                {
                    {"longitude", "32.00000" },
                    {"latitude", "32.00000" },
                    {"dateAndTime", "2020-13-05T23:56:00" },
                },
            }
        };
        internal void CreateFlight(IFlightModel iflight)
        {
            for (int i = 0; i < FlightPlan.Count; i++)
            {
                Flight f = new Flight();
                f.CompanyName = FlightPlan[i].CompanyName;
                f.FlightID = "london";//FlightPlan[i].CompanyName;
                f.IsExternal = false;
                f.NumberOfPassenger = FlightPlan[i].NumberOfPassenger;
                FlightPlan[i].Initial_location.TryGetValue("latitude", out string valuelat);
                FlightPlan[i].Initial_location.TryGetValue("longitude", out string valuelng);
                FlightPlan[i].Initial_location.TryGetValue("d", out string dateAndTime);
                f.DateAndTime = dateAndTime;
                try
                {
                    f.Latitude = Double.Parse(valuelat);
                    f.Longitude = Double.Parse(valuelng);

                }
                catch (Exception)
                {
                    throw new Exception("error in parsing at createFlight function");
                }
                iflight.AddFlight(f);

            }
        }

        private void Example()
        {
            List<Dictionary<string, double>> d = new List<Dictionary<string, double>>();
            for (int i = 0; i < 6; i++)
            {
                double lng = 32.00000, lat = 32.00000, DateAndSpan = 650;
                new Dictionary<string, double>()
                    {
                        { "longitude", lng+0.00005 },
                        { "latitude", lat + 0.00005 },
                        { "dataAndTime", DateAndSpan + 5 },

                    };
            }
            FlightPlan[0].Segments = d;
        }

    }
}
