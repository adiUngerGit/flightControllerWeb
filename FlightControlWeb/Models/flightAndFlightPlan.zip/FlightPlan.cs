﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FlightControlWeb.Models
{
    public class FlightPlan
    {
        public string CompanyName { get; set; }
        public int NumberOfPassenger { get; set; }
        public Dictionary<string, string> Initial_location{ get;set; }
        // inside will be longitude, latitude, dataAndTime
        public List<Dictionary<string, double>> Segments { get; set; }
        // array of directory with longitude latitude, timespanInSeconds
    }
}
